Cahaya77 Purple AMP Landing Page

Generated from uploaded WordPress AMP theme:
- Static responsive AMP page
- Unused WordPress PHP/CSS/font files removed
- UI red accents replaced with purple
- Core image assets kept so logos/icons/games/payment images display
- Some non-brand raster assets were red-to-purple adjusted
- Bank/provider logos are preserved to avoid breaking brand readability

Deploy to Lightsail:
sudo rsync -av ./ /opt/bitnami/apache/htdocs/cahaya77/

Required final structure:
/opt/bitnami/apache/htdocs/cahaya77/index.html
/opt/bitnami/apache/htdocs/cahaya77/robots.txt
/opt/bitnami/apache/htdocs/cahaya77/sitemap.xml
/opt/bitnami/apache/htdocs/cahaya77/assets/

Replace for another LP:
- Cahaya77 -> keyword baru
- https://cahaya77.bluemooseevents.com/ -> URL subdomain baru
- Update meta title, description, canonical, og:url, sitemap
- Update CTA URLs:
  #login, #daftar, WhatsApp, Telegram

No Apache restart is needed for HTML/assets changes.
