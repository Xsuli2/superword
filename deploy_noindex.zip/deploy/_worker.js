export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    const noIndexHeaders = {
      "X-Robots-Tag": "noindex, nofollow, noarchive, nosnippet",
      "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
      "Pragma": "no-cache"
    };

    // Blok crawler via robots.txt
    if (url.pathname === "/robots.txt") {
      return new Response("User-agent: *\nDisallow: /\n", {
        status: 200,
        headers: {
          "Content-Type": "text/plain; charset=utf-8",
          ...noIndexHeaders
        }
      });
    }

    // Supaya favicon tidak ikut di-request/index
    if (url.pathname === "/favicon.ico") {
      return new Response(null, {
        status: 204,
        headers: noIndexHeaders
      });
    }

    // Ambil target dari Cloudflare Pages > Settings > Environment variables
    const target = env.SECRET_TARGET_URL;
    if (!target) {
      return new Response("No target configured", {
        status: 500,
        headers: noIndexHeaders
      });
    }

    // Redirect tetap jalan, tapi kasih sinyal noindex di HTTP header
    return new Response(null, {
      status: 302,
      headers: {
        "Location": target,
        ...noIndexHeaders
      }
    });
  }
};
