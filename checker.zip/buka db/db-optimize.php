<?php
/**
 * Secure Weekly Database Optimizer with Log Rotation
 * Version: 1.2-final (for Namecheap cron)
 */

// Jalankan hanya lewat CLI / cron, bukan browser
if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    die("Script ini hanya dapat dijalankan melalui cron job.");
}

// Path file konfigurasi (.dbconfig.ini)
$configPath = dirname(__FILE__) . '/.dbconfig.ini';
$config = parse_ini_file($configPath);

// Validasi konfigurasi
if (!$config || empty($config['DB_USER']) || empty($config['DB_PASS'])) {
    die("Konfigurasi database tidak ditemukan atau tidak valid.\n");
}

// Koneksi ke MySQL
$host = "localhost";
$user = $config['DB_USER'];
$pass = $config['DB_PASS'];
$conn = new mysqli($host, $user, $pass);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error . "\n");
}

// Lokasi file log (di luar public_html)
$logFile = dirname(__FILE__) . '/optimize_log.txt';

// Rotasi log (hapus jika lebih dari 7 hari)
if (file_exists($logFile) && (time() - filemtime($logFile) > 7 * 24 * 60 * 60)) {
    unlink($logFile);
}

// Mulai logging
$log = fopen($logFile, 'a');
fwrite($log, "\n==== Optimasi dimulai pada: " . date('Y-m-d H:i:s') . " ====\n");

// Ambil semua database dengan pola wp (WordPress)
$dbs = $conn->query("SHOW DATABASES WHERE `Database` LIKE '%wp%'");

if ($dbs && $dbs->num_rows > 0) {
    while ($db = $dbs->fetch_array()) {
        $dbname = $db[0];
        fwrite($log, "Memproses database: $dbname\n");
        $conn->select_db($dbname);

        $tables = $conn->query("SHOW TABLES");
        while ($t = $tables->fetch_array()) {
            $table = $t[0];
            $result = $conn->query("OPTIMIZE TABLE `$table`");
            if ($result) {
                fwrite($log, "[OK] $table optimized\n");
            } else {
                fwrite($log, "[ERROR] $table: " . $conn->error . "\n");
            }
            usleep(300000); // jeda 0.3 detik antar tabel agar CPU stabil
        }
    }
    fwrite($log, "Semua database telah dioptimasi.\n");
} else {
    fwrite($log, "Tidak ada database ditemukan dengan pola '%wp%'.\n");
}

// Tutup koneksi & log
fwrite($log, "==== Optimasi selesai pada: " . date('Y-m-d H:i:s') . " ====\n");
fclose($log);
$conn->close();

echo "Optimasi mingguan selesai.\n";
?>w