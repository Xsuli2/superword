<?php
/**
 * Secure Database Optimizer for Namecheap Cron
 * Version: 2.1 (Single File + INI Config, Cron-Safe)
 */

/* ======================================================
   BASIC ENV & LOG SETUP (WAJIB PALING ATAS)
====================================================== */

if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    exit("Forbidden\n");
}

$baseDir  = __DIR__;
$logFile  = $baseDir . '/optimize_log.txt';
$errorLog = $baseDir . '/php_error.log';

if (file_exists($logFile) && time() - filemtime($logFile) > 7 * 86400) {
    unlink($logFile);
}


ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', $errorLog);
error_reporting(E_ALL);

function logmsg($msg) {
    global $logFile;
    file_put_contents(
        $logFile,
        '[' . date('Y-m-d H:i:s') . '] ' . $msg . PHP_EOL,
        FILE_APPEND | LOCK_EX
    );
}

logmsg('CRON STARTED');

/* ======================================================
   LOAD DATABASE CONFIG FROM .INI (AMAN)
====================================================== */

// GANTI USERNAME SESUAI AKUN HOSTING KAMU
$configPath = '/home/ninjouot/.dbconfig.ini';

$config = parse_ini_file($configPath);

if ($config === false) {
    logmsg("ERROR: Cannot read dbconfig.ini at {$configPath}");
    exit(1);
}

$dbHost = $config['DB_HOST'] ?? 'localhost';
$dbUser = $config['DB_USER'] ?? '';
$dbPass = $config['DB_PASS'] ?? '';

if ($dbUser === '' || $dbPass === '') {
    logmsg("ERROR: Database credentials missing in dbconfig.ini");
    exit(1);
}

logmsg('Database config loaded successfully');

/* ======================================================
   MYSQL CONNECTION
====================================================== */

$conn = new mysqli($dbHost, $dbUser, $dbPass);

if ($conn->connect_error) {
    logmsg('ERROR: MySQL connection failed - ' . $conn->connect_error);
    exit(1);
}

logmsg('MySQL connected successfully');

/* ======================================================
   GET DATABASE LIST
====================================================== */

$dbResult = $conn->query('SHOW DATABASES');

if (!$dbResult) {
    logmsg('ERROR: Failed to fetch database list');
    exit(1);
}

$skipDB = [
    'information_schema',
    'mysql',
    'performance_schema',
    'sys'
];

while ($dbRow = $dbResult->fetch_assoc()) {

    $dbName = $dbRow['Database'];

    if (in_array($dbName, $skipDB, true)) {
        continue;
    }

    logmsg("Processing database: {$dbName}");

    if (!$conn->select_db($dbName)) {
        logmsg("ERROR: Cannot select database {$dbName}");
        continue;
    }

    $tables = $conn->query('SHOW TABLES');

    if (!$tables) {
        logmsg("ERROR: Failed to list tables in {$dbName}");
        continue;
    }

    while ($tbl = $tables->fetch_array()) {
        $table = $tbl[0];

        // Skip WordPress transient / cache / session tables
        if (preg_match('/_transient_|_cache_|_session_/i', $table)) {
            continue;
        }

        if ($conn->query("OPTIMIZE TABLE `{$table}`")) {
            logmsg("Optimized: {$dbName}.{$table}");
        } else {
            logmsg("ERROR: Failed optimizing {$dbName}.{$table}");
        }
    }
}

$conn->close();
logmsg('CRON FINISHED SUCCESSFULLY');
exit(0);
