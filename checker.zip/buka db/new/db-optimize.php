<?php
/**
 * FINAL SIMPLE & SAFE Auto DB Optimizer
 * FIXED fetch_row() bug
 */

if (php_sapi_name() !== 'cli') exit;

// ===== KONFIG
$DB_HOST   = 'localhost';
$DB_USER   = 'ninjyjyh'; 
$DB_PASS   = 'nxmGO0keSXRz';
$DB_PREFIX = 'ninjyjyh_wp'; 

// ===== PATH
$base   = __DIR__;
$lock   = $base . '/db-optimize.lock';
$logDir = $base . '/logs';

// ===== LOCK
if (file_exists($lock)) exit;
file_put_contents($lock, getmypid());

// ===== LOG DIR
if (!is_dir($logDir)) {
    mkdir($logDir, 0700, true);
}
$logFile = $logDir . '/db-optimize-' . date('Y-m-d') . '.log';

// ===== DELETE LOG > 7 HARI
$now = time();
foreach (glob($logDir . '/db-optimize-*.log') as $f) {
    if ($now - filemtime($f) > 7 * 86400) {
        unlink($f);
    }
}

file_put_contents($logFile, date('H:i:s')." START\n", FILE_APPEND);

// ===== CONNECT
$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS);
if ($conn->connect_error) {
    file_put_contents($logFile, date('H:i:s')." DB CONNECT ERROR\n", FILE_APPEND);
    unlink($lock);
    exit;
}

// ===== QUERY DATABASES
$dbs = $conn->query("SHOW DATABASES LIKE '{$DB_PREFIX}%'");
if (!$dbs || $dbs->num_rows === 0) {
    file_put_contents($logFile, date('H:i:s')." NO DATABASE FOUND\n", FILE_APPEND);
    $conn->close();
    unlink($lock);
    exit;
}

// ===== TABEL WP INTI
$coreTables = [
    'posts','postmeta','options',
    'terms','term_taxonomy',
    'term_relationships','usermeta'
];

// ===== LOOP DB (FIXED)
while ($row = $dbs->fetch_row()) {
    $db = $row[0];
    $conn->select_db($db);

    foreach ($coreTables as $t) {
        $table = "{$DB_PREFIX}_{$t}";
        $conn->query("OPTIMIZE TABLE `$table`");
    }

    file_put_contents(
        $logFile,
        date('H:i:s')." OK {$db}\n",
        FILE_APPEND
    );

    sleep(5);
}

$conn->close();
file_put_contents($logFile, date('H:i:s')." DONE\n", FILE_APPEND);
unlink($lock);
