<?php
if (php_sapi_name() !== 'cli') exit;

$DB_HOST = 'localhost';
$DB_USER = 'ninjyjyh';
$DB_PASS = 'nxmGO0keSXRz';
$DB_PREFIX = 'ninjyjyh_wp';

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS);
if ($conn->connect_error) exit("DB error\n");

$dbs = $conn->query("SHOW DATABASES LIKE '{$DB_PREFIX}%'");
while ($row = $dbs->fetch_row()) {
    $db = $row[0];
    $conn->select_db($db);

    $sqls = [
        "ALTER TABLE {$DB_PREFIX}_term_relationships ADD INDEX term_taxonomy_id_idx (term_taxonomy_id)",
        "ALTER TABLE {$DB_PREFIX}_postmeta ADD INDEX post_id_idx (post_id)",
        "ALTER TABLE {$DB_PREFIX}_posts ADD INDEX post_type_idx (post_type)"
    ];

    foreach ($sqls as $sql) {
        @$conn->query($sql); // suppress duplicate index warning
    }

    echo "OK {$db}\n";
}

$conn->close();
