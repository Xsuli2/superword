#!/usr/bin/env python3
# Generated: 2025-10-13 03:37:06
# Single-file Rank Checker for SearchApi.io
# - Uses one request per keyword per page (max 2 pages), scans results for many domains.
# - Keywords are auto-derived from each domain (domain label without TLD), per user request.
# - Location fixed to "Indonesia". Stops early if found on page 1 and opens the found URL in a new browser window.

import os
import time
import csv
import sys
import requests
import webbrowser

API_URL = "https://www.searchapi.io/api/v1/search"

# === USER CONFIG ===
LOCATION = "Indonesia"     # fixed per user request
DEVICE = "desktop"         # "desktop" or "mobile"
PAGES = 2                  # max page to check (1..2); early-stop if found on page 1
SLEEP_BETWEEN_CALLS = 0.8  # seconds

# Prefer API key from env; otherwise prompt the user once at runtime.
API_KEY = os.getenv("SEARCHAPI_KEY")

DOMAINS = [
    "banjir303.org",
    "mpoliga.org",
    "ugplus64.net",
    "jambakpro56.com",
    "jelasjp69.net",
    "angkelbet78.net",
    "bul798pro.net",
    "rajapoker363.org",
    "cogan77.org",
    "pumawin89.net",
    "timedamri53.org",
    "cy14win.net",
    "topwd79.org",
    "jaya43.net",
    "lapan4d.net",
    "lgosuper22.com",
    "bebycuan89.net",
    "molibet56.net",
    "kera606.net",
    "super999cuan.net",
    "maxgoal33.com",
    "lotusplay66.net",
    "desawin44.net",
    "dewaserver44.com",
    "tunamax166.org",
    "hayangjp606.org",
    "superpln678.org",
    "xiao45pro.net",
    "satoto76.com",
    "maxi66.org",
    "promintul.com",
    "starbet01.com",
    "polo303bet.org",
    "ratudomino88.com",
    "spbuwin987.org",
    "lgoprovip23.org",
    "kayu43.org",
    "gorebet77.org",
    "bigace155.net",
    "bintangcuan66.com",
    "boom99wd.com",
    "bosjp73.org",
    "bom78top.net",
    "boslgo303.net",
    "rajapalu36.org",
    "cuanpro87.org",
    "cuanprohub.net",
    "indo99pro.net",
    "dutaking79.org",
    "lunatoto122.org",
    "pohonwd67.net",
    "agenjp65.net",
    "superlaku987.net",
    "kala56.net",
    "pinus189.com",
    "maransi66.net",
    "mpogas.org",
    "kinglaku07.org",
    "slotmacaus188.com",
    "maxwins88.com",
    "pariswin55.net",
    "mpogas.net",
    "wildjepe88.com",
    "lux43.org",
    "maroko65.org",
    "mafiacuan167.net",
    "jagowin46.net",
    "kristal78.org",
    "jegerwd57.net",
    "procuan178.org",
    "nukewin87.net",
    "marlesjp99.net",
    "marswd606.net",
    "jinwd606.net",
    "petirtop789.org",
    "romwd606.org",
    "roomtoto99.org",
    "samba909.org",
    "club189pro.org",
    "otong17.org",
    "susahkalah33.net",
    "hotwin76.com",
    "gasyok78.org",
    "webtoto189.net",
    "lgo33pro.org",
    "pusatwar67.org",
    "alexis67.org",
    "senjajp75.org",
    "indo55win.net",
    "playslot45.net"
]

def keyword_from_domain(domain: str) -> str:
    parts = domain.split(".")
    if len(parts) >= 2:
        return parts[-2]
    return parts[0]

def fetch_serp(api_key: str, keyword: str, page: int):
    params = {
        "engine": "google",
        "q": keyword,
        "page": page,
        "device": DEVICE,
        "location": LOCATION,
        "api_key": api_key,
    }
    r = requests.get(API_URL, params=params, timeout=60)
    if r.status_code != 200:
        raise RuntimeError(f"API error {r.status_code}: {r.text[:200]}")
    return r.json()

def find_rank_for_domain(organic_results, domain: str, page: int):
    # organic_results is a list where each item may have "link" and "title"
    # Positions: 1..10 for page 1, 11..20 for page 2
    base = 1 + (page - 1) * 10
    for idx, item in enumerate(organic_results or [], start=base):
        link = (item or {}).get("link") or ""
        title = (item or {}).get("title") or ""
        if domain.lower() in link.lower():
            return idx, link, title
    return None, "", ""

def main():
    global API_KEY
    if not API_KEY:
        try:
            API_KEY = input("Enter your SearchApi.io API key (or set SEARCHAPI_KEY env): ").strip()
        except EOFError:
            API_KEY = ""
    if not API_KEY:
        print("[ERROR] Missing API key. Set SEARCHAPI_KEY or provide it via input.", file=sys.stderr)
        sys.exit(1)

    # Build keywords from domains
    pairs = [ (keyword_from_domain(dm), dm) for dm in DOMAINS ]

    out_path = "hasil.csv"
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["keyword", "domain", "rank", "page_found", "url", "title"])

        total_calls = 0
        for kw, dm in pairs:
            print(f"\n[KW] {kw}  |  Domain: {dm}")
            found = False

            # Page 1
            try:
                data = fetch_serp(API_KEY, kw, page=1)
                total_calls += 1
            except Exception as e:
                print(f"  ! API error page1: {e}")
                w.writerow([kw, dm, "ERROR", "1", "", str(e)])
                continue

            rank, url, title = find_rank_for_domain(data.get("organic_results", []), dm, page=1)
            if rank is not None:
                print(f"  ✓ FOUND on page 1 at position #{rank} -> {url}")
                w.writerow([kw, dm, rank, 1, url, title])
                # Open the found URL in a new browser window (best-effort)
                try:
                    webbrowser.open_new(url)
                except Exception as e:
                    print(f"  (browser open failed: {e})")
                found = True
            else:
                print("  - Not on page 1")

            # Early stop if found on page 1
            if found:
                time.sleep(SLEEP_BETWEEN_CALLS)
                continue

            # Page 2 (only if not found on page 1 and PAGES >= 2)
            if PAGES >= 2:
                try:
                    data2 = fetch_serp(API_KEY, kw, page=2)
                    total_calls += 1
                except Exception as e:
                    print(f"  ! API error page2: {e}")
                    w.writerow([kw, dm, "ERROR", "2", "", str(e)])
                    time.sleep(SLEEP_BETWEEN_CALLS)
                    continue

                rank, url, title = find_rank_for_domain(data2.get("organic_results", []), dm, page=2)
                if rank is not None:
                    print(f"  ✓ FOUND on page 2 at position #{rank} -> {url}")
                    w.writerow([kw, dm, rank, 2, url, title])
                else:
                    print("  × NOT FOUND within top 20")
                    w.writerow([kw, dm, "NA", "NA", "", ""])

            time.sleep(SLEEP_BETWEEN_CALLS)

    print(f"\n[DONE] Wrote: {out_path}")
    print("Reminder: each request consumes 1 credit on SearchApi.io")
    print("Tip: Reduce pages or pairs to save credits.")

if __name__ == "__main__":
    main()
